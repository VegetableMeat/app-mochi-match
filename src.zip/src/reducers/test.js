const initialState = {
    title: 'もちまっちげーみんぐ',
    copyRight: 'Copy right もちまっちげーみんぐ'
};

export default function testReducer(state = initialState) {
    
}
