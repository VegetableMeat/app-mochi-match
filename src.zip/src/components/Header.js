import React from 'react';
import Menu from './Menu';

export default function Header() {
    return (
        <div>
            ヘッダー
            <Menu />
        </div>   
    )
}